package bean;
import java.sql.*;
import static bean.Provider.*;

public class ConnectionProvider {
	static Connection con=null;
	static String DRIVER="com.mysql.jdbc.Driver";
	static String CONNECTION_URL="jdbc:mysql://localhost:3306/testdb?useSSL=false&user=john&password=pass1234";
	static String USERNAME="john";
	static String PASSWORD="pass1234";
	static{
		try{
			Class.forName(DRIVER);
			con=DriverManager.getConnection(CONNECTION_URL,USERNAME,PASSWORD);
			}catch(Exception e){}
	}
	public static Connection getCon(){
		return con;
	}
}
