package bean;
import java.sql.Date;

public class Transact {
    private static final String String = null;
    
    protected String transname = null;
    protected Integer dollaramt = 0;
    protected Integer ppsamt = 0;
    protected Integer ppsbal = 0;
    protected String fuser = null;
    protected String tuser = null;
 
    public Transact() {
    }
 
    public Transact(String fuser) {
        this.fuser = fuser;
    }
 
    public Transact(String fuser, String tuser) {
        this.fuser = fuser;
        this.tuser = tuser;
    }
     
    public String gettransname() {
        return transname;
    }
 
    public void settransname(String transname) {
        this.transname = transname;
    }
    public Integer getdollaramt() {
        return dollaramt;
    }
 
    public void setdollaramt(Integer dollaramt) {
        this.dollaramt = dollaramt;
    }
    public Integer getppsamt() {
        return ppsamt;
    }
 
    public void setppsamt(Integer ppsamt) {
        this.ppsamt = ppsamt;
    }
    public Integer getppsbal() {
        return ppsbal;
    }
 
    public void setppsbal(Integer ppsbal) {
        this.ppsbal = ppsbal;
    }
    public String getfuser() {
        return fuser;
    }
 
    public void setfuser(String fuser) {
        this.fuser = fuser;
    }
    public String gettuser() {
        return tuser;
    }
 
    public void settuser(String tuser) {
        this.tuser = tuser;
    }
}