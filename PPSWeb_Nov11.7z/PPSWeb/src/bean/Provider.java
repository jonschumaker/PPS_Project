package bean;

public interface Provider {
String DRIVER="com.mysql.jdbc.Driver";
String CONNECTION_URL="jdbc:mysql://localhost:3306/testdb?useSSL=false&user=john&password=pass1234";
String USERNAME="john";
String PASSWORD="pass1234";

}
