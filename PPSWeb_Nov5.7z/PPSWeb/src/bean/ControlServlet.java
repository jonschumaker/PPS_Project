package bean;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Date;
import java.text.ParseException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Date;
import java.text.SimpleDateFormat;

/**
 * ControlServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the user.
 * @author www.codejava.net
 */
public class ControlServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Initialize initialize;

    public void init() {
        initialize = new Initialize();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("doPost started: 000000000000000000000000000");
        doGet(request, response);
        System.out.println("doPost finished: 11111111111111111111111111");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("doGet started: 000000000000000000000000000");

        String action = request.getServletPath();
        System.out.println(action);
        try {
            switch (action) {

            case "/new":
                System.out.println("The action is: new");
                showNewForm(request, response);
                break;
            case "/insert":
                System.out.println("The action is: insert");
            	   insertPeople(request, response);
                break;


            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
        System.out.println("doGet finished: 111111111111111111111111111111111111");
    }



    // to insert a people
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("showNewForm started: 000000000000000000000000000");

        RequestDispatcher dispatcher = request.getRequestDispatcher("Newuser.jsp");
        dispatcher.forward(request, response);
        System.out.println("The user sees the Newuser page now.");

        System.out.println("showNewForm finished: 1111111111111111111111111111111");
    }


    // after the data of a people are inserted, this method will be called to insert the new people into the DB

    private void insertPeople(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        System.out.println("insertPeople started: 000000000000000000000000000");
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        String emailid=request.getParameter("emailid");
        String password = request.getParameter("password");
        String password2 = request.getParameter("password2");
        String fName = request.getParameter("fName");
        String lname = request.getParameter("lname");
        String address = request.getParameter("address");
        String birthString = request.getParameter("birthday");
        Date birthday = null;
		try {
			birthday = format.parse(birthString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
// birthday = request.getParameter("birthday");
        System.out.println("emailid:" + emailid + "password:" + password + "password2:" + password2 +"fName:" + fName + "lname:" + lname + ", address: "+address + ", birthday:" + birthday);

        People newPeople = new People(emailid,password,password2,fName,lname, address, birthday);
        initialize.insertNewUser(newPeople);

        //System.out.println("Ask the browser to call the list action next automatically");
        //response.sendRedirect("list");  //

        System.out.println("insertPeople finished: 11111111111111111111111111");
    }




}
